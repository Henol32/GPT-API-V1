/*
 * FlightControlSystemCascadedV2_data.c
 *
 * Code generation for model "FlightControlSystemCascadedV2".
 *
 * Model version              : 1.48
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Mon Jun 30 13:11:24 2025
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FlightControlSystemCascadedV2.h"

/* Block parameters (default storage) */
P_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_P = {
  /* Mask Parameter: AltitudePID_D
   * Referenced by: '<S32>/Derivative Gain'
   */
  0.2,

  /* Mask Parameter: PitchPD_D
   * Referenced by: '<S80>/Derivative Gain'
   */
  0.0,

  /* Mask Parameter: AltitudePID_I
   * Referenced by: '<S35>/Integral Gain'
   */
  0.001,

  /* Mask Parameter: AltitudePID_InitialConditionFor
   * Referenced by: '<S33>/Filter'
   */
  0.0,

  /* Mask Parameter: PitchPD_InitialConditionForFilt
   * Referenced by: '<S81>/Filter'
   */
  0.0,

  /* Mask Parameter: AltitudePID_InitialConditionF_o
   * Referenced by: '<S38>/Integrator'
   */
  0.0,

  /* Mask Parameter: Ramp_InitialOutput
   * Referenced by: '<S3>/Constant1'
   */
  0.0,

  /* Mask Parameter: AltitudePID_Kb
   * Referenced by: '<S31>/Kb'
   */
  0.0001,

  /* Mask Parameter: AltitudePID_LowerIntegratorSatu
   * Referenced by: '<S38>/Integrator'
   */
  -25.0,

  /* Mask Parameter: AltitudePID_LowerSaturationLimi
   * Referenced by: '<S45>/Saturation'
   */
  -25.0,

  /* Mask Parameter: AltitudePID_N
   * Referenced by: '<S41>/Filter Coefficient'
   */
  100.0,

  /* Mask Parameter: PitchPD_N
   * Referenced by: '<S89>/Filter Coefficient'
   */
  100.0,

  /* Mask Parameter: AltitudePID_P
   * Referenced by: '<S43>/Proportional Gain'
   */
  0.02,

  /* Mask Parameter: PitchPD_P
   * Referenced by: '<S91>/Proportional Gain'
   */
  1.0,

  /* Mask Parameter: AltitudePID_UpperIntegratorSatu
   * Referenced by: '<S38>/Integrator'
   */
  25.0,

  /* Mask Parameter: AltitudePID_UpperSaturationLimi
   * Referenced by: '<S45>/Saturation'
   */
  25.0,

  /* Mask Parameter: ActualAltitude0_const
   * Referenced by: '<S103>/Constant'
   */
  0.0,

  /* Mask Parameter: ActualAltitude4_const
   * Referenced by: '<S106>/Constant'
   */
  13000.0,

  /* Mask Parameter: ActualAltitude1_const
   * Referenced by: '<S104>/Constant'
   */
  -0.5236,

  /* Mask Parameter: ActualAltitude1_const_f
   * Referenced by: '<S105>/Constant'
   */
  0.5236,

  /* Mask Parameter: Lessthan30_const
   * Referenced by: '<S108>/Constant'
   */
  -0.5236,

  /* Mask Parameter: Morethan30_const
   * Referenced by: '<S110>/Constant'
   */
  0.5236,

  /* Mask Parameter: Lessthan0m_const
   * Referenced by: '<S107>/Constant'
   */
  0.0,

  /* Mask Parameter: Morethan12000m_const
   * Referenced by: '<S109>/Constant'
   */
  12000.0,

  /* Mask Parameter: Ramp_slope
   * Referenced by: '<S3>/Step'
   */
  0.2,

  /* Mask Parameter: Ramp_start
   * Referenced by:
   *   '<S3>/Constant'
   *   '<S3>/Step'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Altitude_Integrator'
   */
  0.0,

  /* Expression: 3
   * Referenced by: '<Root>/Constant1'
   */
  3.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step_DesiredAltitude'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Step_DesiredAltitude'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Step_DesiredAltitude'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S3>/Step'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<Root>/Sine Wave'
   */
  10.0,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave'
   */
  0.0,

  /* Expression: 0.0628
   * Referenced by: '<Root>/Sine Wave'
   */
  0.0628,

  /* Expression: 0
   * Referenced by: '<Root>/Sine Wave'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<Root>/Signal Generator'
   */
  1.0,

  /* Computed Parameter: SignalGenerator_Frequency
   * Referenced by: '<Root>/Signal Generator'
   */
  0.0477464829275686,

  /* Expression: 6
   * Referenced by: '<Root>/Signal Generator1'
   */
  6.0,

  /* Computed Parameter: SignalGenerator1_Frequency
   * Referenced by: '<Root>/Signal Generator1'
   */
  0.031830988618379068,

  /* Expression: 1
   * Referenced by: '<Root>/Manual Elevator Cmd'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<Root>/Manual Elevator Cmd'
   */
  0.0,

  /* Expression: 10
   * Referenced by: '<Root>/Manual Elevator Cmd'
   */
  10.0,

  /* Expression: 0
   * Referenced by: '<Root>/Safe elevator cmd'
   */
  0.0,

  /* Computed Parameter: TransferFcnpitch_A
   * Referenced by: '<Root>/Transfer Fcn (pitch)'
   */
  { -2.1, -2.25 },

  /* Computed Parameter: TransferFcnpitch_C
   * Referenced by: '<Root>/Transfer Fcn (pitch)'
   */
  { 0.0, 0.5 },

  /* Expression: 0.0873
   * Referenced by: '<S1>/Rate Limiter'
   */
  0.0873,

  /* Expression: -0.0873
   * Referenced by: '<S1>/Rate Limiter'
   */
  -0.0873,

  /* Expression: 0.087
   * Referenced by: '<Root>/Actuator limiter'
   */
  0.087,

  /* Expression: -0.087
   * Referenced by: '<Root>/Actuator limiter'
   */
  -0.087,

  /* Expression: 1
   * Referenced by: '<Root>/Constant2'
   */
  1.0,

  /* Expression: 50
   * Referenced by: '<Root>/Pitch disturbance step'
   */
  50.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pitch disturbance step'
   */
  0.0,

  /* Expression: 0.05
   * Referenced by: '<Root>/Pitch disturbance step'
   */
  0.05,

  /* Expression: 1
   * Referenced by: '<Root>/Pitch disturbance pulse'
   */
  1.0,

  /* Computed Parameter: Pitchdisturbancepulse_Period
   * Referenced by: '<Root>/Pitch disturbance pulse'
   */
  10000.0,

  /* Computed Parameter: Pitchdisturbancepulse_Duty
   * Referenced by: '<Root>/Pitch disturbance pulse'
   */
  500.0,

  /* Expression: 0
   * Referenced by: '<Root>/Pitch disturbance pulse'
   */
  0.0,

  /* Expression: 9.8
   * Referenced by: '<Root>/Gain (PitchRateToSpeed)'
   */
  9.8,

  /* Expression: 0
   * Referenced by: '<Root>/Vertical speed'
   */
  0.0,

  /* Computed Parameter: AutomaticManualmode_CurrentSett
   * Referenced by: '<Root>/Automatic//Manual mode'
   */
  0U
};
