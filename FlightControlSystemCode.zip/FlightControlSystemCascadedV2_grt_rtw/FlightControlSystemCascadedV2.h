/*
 * FlightControlSystemCascadedV2.h
 *
 * Code generation for model "FlightControlSystemCascadedV2".
 *
 * Model version              : 1.48
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Mon Jun 30 13:11:24 2025
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_FlightControlSystemCascadedV2_h_
#define RTW_HEADER_FlightControlSystemCascadedV2_h_
#ifndef FlightControlSystemCascadedV2_COMMON_INCLUDES_
#define FlightControlSystemCascadedV2_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                      /* FlightControlSystemCascadedV2_COMMON_INCLUDES_ */

#include "FlightControlSystemCascadedV2_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#include <float.h>
#include <string.h>
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#define FlightControlSystemCascadedV2_M (FlightControlSystemCascadedV_M)

/* Block signals (default storage) */
typedef struct {
  real_T ActualAltitude;               /* '<Root>/Altitude_Integrator' */
  real_T MultiportSwitch;              /* '<Root>/Multiport Switch' */
  real_T RateLimiter;                  /* '<S1>/Rate Limiter' */
  real_T FilterCoefficient;            /* '<S41>/Filter Coefficient' */
  real_T FilterCoefficient_h;          /* '<S89>/Filter Coefficient' */
  real_T Actuatorlimiter;              /* '<Root>/Actuator limiter' */
  real_T Pitchdisturbancepulse;        /* '<Root>/Pitch disturbance pulse' */
  real_T Sumdisturbance;               /* '<Root>/Sum disturbance' */
  real_T SumI4;                        /* '<S31>/SumI4' */
  real_T VerticalAcceleration;         /* '<Root>/Gain (PitchRateToSpeed)' */
  real_T Verticalspeed;                /* '<Root>/Vertical speed' */
  boolean_T LogicalOperator;           /* '<S2>/Logical Operator' */
} B_FlightControlSystemCascaded_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T PrevY;                        /* '<S1>/Rate Limiter' */
  real_T LastMajorTime;                /* '<S1>/Rate Limiter' */
  real_T PrevY_g;                      /* '<Root>/Actuator limiter' */
  real_T LastMajorTime_a;              /* '<Root>/Actuator limiter' */
  int32_T clockTickCounter;            /* '<Root>/Pitch disturbance pulse' */
  boolean_T PrevLimited;               /* '<S1>/Rate Limiter' */
  boolean_T PrevLimited_g;             /* '<Root>/Actuator limiter' */
} DW_FlightControlSystemCascade_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Altitude_Integrator_CSTATE;   /* '<Root>/Altitude_Integrator' */
  real_T TransferFcnpitch_CSTATE[2];   /* '<Root>/Transfer Fcn (pitch)' */
  real_T Integrator_CSTATE;            /* '<S38>/Integrator' */
  real_T Filter_CSTATE;                /* '<S33>/Filter' */
  real_T Filter_CSTATE_d;              /* '<S81>/Filter' */
  real_T Verticalspeed_CSTATE;         /* '<Root>/Vertical speed' */
} X_FlightControlSystemCascaded_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Altitude_Integrator_CSTATE;   /* '<Root>/Altitude_Integrator' */
  real_T TransferFcnpitch_CSTATE[2];   /* '<Root>/Transfer Fcn (pitch)' */
  real_T Integrator_CSTATE;            /* '<S38>/Integrator' */
  real_T Filter_CSTATE;                /* '<S33>/Filter' */
  real_T Filter_CSTATE_d;              /* '<S81>/Filter' */
  real_T Verticalspeed_CSTATE;         /* '<Root>/Vertical speed' */
} XDot_FlightControlSystemCasca_T;

/* State disabled  */
typedef struct {
  boolean_T Altitude_Integrator_CSTATE;/* '<Root>/Altitude_Integrator' */
  boolean_T TransferFcnpitch_CSTATE[2];/* '<Root>/Transfer Fcn (pitch)' */
  boolean_T Integrator_CSTATE;         /* '<S38>/Integrator' */
  boolean_T Filter_CSTATE;             /* '<S33>/Filter' */
  boolean_T Filter_CSTATE_d;           /* '<S81>/Filter' */
  boolean_T Verticalspeed_CSTATE;      /* '<Root>/Vertical speed' */
} XDis_FlightControlSystemCasca_T;

#ifndef ODE4_INTG
#define ODE4_INTG

/* ODE4 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[4];                        /* derivatives */
} ODE4_IntgData;

#endif

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Altitude;                     /* '<Root>/Altitude' */
} ExtY_FlightControlSystemCasca_T;

/* Parameters (default storage) */
struct P_FlightControlSystemCascaded_T_ {
  real_T AltitudePID_D;                /* Mask Parameter: AltitudePID_D
                                        * Referenced by: '<S32>/Derivative Gain'
                                        */
  real_T PitchPD_D;                    /* Mask Parameter: PitchPD_D
                                        * Referenced by: '<S80>/Derivative Gain'
                                        */
  real_T AltitudePID_I;                /* Mask Parameter: AltitudePID_I
                                        * Referenced by: '<S35>/Integral Gain'
                                        */
  real_T AltitudePID_InitialConditionFor;
                              /* Mask Parameter: AltitudePID_InitialConditionFor
                               * Referenced by: '<S33>/Filter'
                               */
  real_T PitchPD_InitialConditionForFilt;
                              /* Mask Parameter: PitchPD_InitialConditionForFilt
                               * Referenced by: '<S81>/Filter'
                               */
  real_T AltitudePID_InitialConditionF_o;
                              /* Mask Parameter: AltitudePID_InitialConditionF_o
                               * Referenced by: '<S38>/Integrator'
                               */
  real_T Ramp_InitialOutput;           /* Mask Parameter: Ramp_InitialOutput
                                        * Referenced by: '<S3>/Constant1'
                                        */
  real_T AltitudePID_Kb;               /* Mask Parameter: AltitudePID_Kb
                                        * Referenced by: '<S31>/Kb'
                                        */
  real_T AltitudePID_LowerIntegratorSatu;
                              /* Mask Parameter: AltitudePID_LowerIntegratorSatu
                               * Referenced by: '<S38>/Integrator'
                               */
  real_T AltitudePID_LowerSaturationLimi;
                              /* Mask Parameter: AltitudePID_LowerSaturationLimi
                               * Referenced by: '<S45>/Saturation'
                               */
  real_T AltitudePID_N;                /* Mask Parameter: AltitudePID_N
                                        * Referenced by: '<S41>/Filter Coefficient'
                                        */
  real_T PitchPD_N;                    /* Mask Parameter: PitchPD_N
                                        * Referenced by: '<S89>/Filter Coefficient'
                                        */
  real_T AltitudePID_P;                /* Mask Parameter: AltitudePID_P
                                        * Referenced by: '<S43>/Proportional Gain'
                                        */
  real_T PitchPD_P;                    /* Mask Parameter: PitchPD_P
                                        * Referenced by: '<S91>/Proportional Gain'
                                        */
  real_T AltitudePID_UpperIntegratorSatu;
                              /* Mask Parameter: AltitudePID_UpperIntegratorSatu
                               * Referenced by: '<S38>/Integrator'
                               */
  real_T AltitudePID_UpperSaturationLimi;
                              /* Mask Parameter: AltitudePID_UpperSaturationLimi
                               * Referenced by: '<S45>/Saturation'
                               */
  real_T ActualAltitude0_const;        /* Mask Parameter: ActualAltitude0_const
                                        * Referenced by: '<S103>/Constant'
                                        */
  real_T ActualAltitude4_const;        /* Mask Parameter: ActualAltitude4_const
                                        * Referenced by: '<S106>/Constant'
                                        */
  real_T ActualAltitude1_const;        /* Mask Parameter: ActualAltitude1_const
                                        * Referenced by: '<S104>/Constant'
                                        */
  real_T ActualAltitude1_const_f;     /* Mask Parameter: ActualAltitude1_const_f
                                       * Referenced by: '<S105>/Constant'
                                       */
  real_T Lessthan30_const;             /* Mask Parameter: Lessthan30_const
                                        * Referenced by: '<S108>/Constant'
                                        */
  real_T Morethan30_const;             /* Mask Parameter: Morethan30_const
                                        * Referenced by: '<S110>/Constant'
                                        */
  real_T Lessthan0m_const;             /* Mask Parameter: Lessthan0m_const
                                        * Referenced by: '<S107>/Constant'
                                        */
  real_T Morethan12000m_const;         /* Mask Parameter: Morethan12000m_const
                                        * Referenced by: '<S109>/Constant'
                                        */
  real_T Ramp_slope;                   /* Mask Parameter: Ramp_slope
                                        * Referenced by: '<S3>/Step'
                                        */
  real_T Ramp_start;                   /* Mask Parameter: Ramp_start
                                        * Referenced by:
                                        *   '<S3>/Constant'
                                        *   '<S3>/Step'
                                        */
  real_T Altitude_Integrator_IC;       /* Expression: 0
                                        * Referenced by: '<Root>/Altitude_Integrator'
                                        */
  real_T Constant1_Value;              /* Expression: 3
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T Step_DesiredAltitude_Time;    /* Expression: 1
                                        * Referenced by: '<Root>/Step_DesiredAltitude'
                                        */
  real_T Step_DesiredAltitude_Y0;      /* Expression: 0
                                        * Referenced by: '<Root>/Step_DesiredAltitude'
                                        */
  real_T Step_DesiredAltitude_YFinal;  /* Expression: 1
                                        * Referenced by: '<Root>/Step_DesiredAltitude'
                                        */
  real_T Step_Y0;                      /* Expression: 0
                                        * Referenced by: '<S3>/Step'
                                        */
  real_T SineWave_Amp;                 /* Expression: 10
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  real_T SineWave_Bias;                /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  real_T SineWave_Freq;                /* Expression: 0.0628
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  real_T SineWave_Phase;               /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  real_T SignalGenerator_Amplitude;    /* Expression: 1
                                        * Referenced by: '<Root>/Signal Generator'
                                        */
  real_T SignalGenerator_Frequency;
                                /* Computed Parameter: SignalGenerator_Frequency
                                 * Referenced by: '<Root>/Signal Generator'
                                 */
  real_T SignalGenerator1_Amplitude;   /* Expression: 6
                                        * Referenced by: '<Root>/Signal Generator1'
                                        */
  real_T SignalGenerator1_Frequency;
                               /* Computed Parameter: SignalGenerator1_Frequency
                                * Referenced by: '<Root>/Signal Generator1'
                                */
  real_T ManualElevatorCmd_Time;       /* Expression: 1
                                        * Referenced by: '<Root>/Manual Elevator Cmd'
                                        */
  real_T ManualElevatorCmd_Y0;         /* Expression: 0
                                        * Referenced by: '<Root>/Manual Elevator Cmd'
                                        */
  real_T ManualElevatorCmd_YFinal;     /* Expression: 10
                                        * Referenced by: '<Root>/Manual Elevator Cmd'
                                        */
  real_T Safeelevatorcmd_Value;        /* Expression: 0
                                        * Referenced by: '<Root>/Safe elevator cmd'
                                        */
  real_T TransferFcnpitch_A[2];        /* Computed Parameter: TransferFcnpitch_A
                                        * Referenced by: '<Root>/Transfer Fcn (pitch)'
                                        */
  real_T TransferFcnpitch_C[2];        /* Computed Parameter: TransferFcnpitch_C
                                        * Referenced by: '<Root>/Transfer Fcn (pitch)'
                                        */
  real_T RateLimiter_RisingLim;        /* Expression: 0.0873
                                        * Referenced by: '<S1>/Rate Limiter'
                                        */
  real_T RateLimiter_FallingLim;       /* Expression: -0.0873
                                        * Referenced by: '<S1>/Rate Limiter'
                                        */
  real_T Actuatorlimiter_RisingLim;    /* Expression: 0.087
                                        * Referenced by: '<Root>/Actuator limiter'
                                        */
  real_T Actuatorlimiter_FallingLim;   /* Expression: -0.087
                                        * Referenced by: '<Root>/Actuator limiter'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<Root>/Constant2'
                                        */
  real_T Pitchdisturbancestep_Time;    /* Expression: 50
                                        * Referenced by: '<Root>/Pitch disturbance step'
                                        */
  real_T Pitchdisturbancestep_Y0;      /* Expression: 0
                                        * Referenced by: '<Root>/Pitch disturbance step'
                                        */
  real_T Pitchdisturbancestep_YFinal;  /* Expression: 0.05
                                        * Referenced by: '<Root>/Pitch disturbance step'
                                        */
  real_T Pitchdisturbancepulse_Amp;    /* Expression: 1
                                        * Referenced by: '<Root>/Pitch disturbance pulse'
                                        */
  real_T Pitchdisturbancepulse_Period;
                             /* Computed Parameter: Pitchdisturbancepulse_Period
                              * Referenced by: '<Root>/Pitch disturbance pulse'
                              */
  real_T Pitchdisturbancepulse_Duty;
                               /* Computed Parameter: Pitchdisturbancepulse_Duty
                                * Referenced by: '<Root>/Pitch disturbance pulse'
                                */
  real_T Pitchdisturbancepulse_PhaseDela;/* Expression: 0
                                          * Referenced by: '<Root>/Pitch disturbance pulse'
                                          */
  real_T GainPitchRateToSpeed_Gain;    /* Expression: 9.8
                                        * Referenced by: '<Root>/Gain (PitchRateToSpeed)'
                                        */
  real_T Verticalspeed_IC;             /* Expression: 0
                                        * Referenced by: '<Root>/Vertical speed'
                                        */
  uint8_T AutomaticManualmode_CurrentSett;
                          /* Computed Parameter: AutomaticManualmode_CurrentSett
                           * Referenced by: '<Root>/Automatic//Manual mode'
                           */
};

/* Real-time Model Data Structure */
struct tag_RTM_FlightControlSystemCa_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_FlightControlSystemCascaded_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  XDis_FlightControlSystemCasca_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[7];
  real_T odeF[4][7];
  ODE4_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tStart;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_P;

/* Block signals (default storage) */
extern B_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_B;

/* Continuous states (default storage) */
extern X_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_X;

/* Disabled states (default storage) */
extern XDis_FlightControlSystemCasca_T FlightControlSystemCascade_XDis;

/* Block states (default storage) */
extern DW_FlightControlSystemCascade_T FlightControlSystemCascadedV_DW;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_FlightControlSystemCasca_T FlightControlSystemCascadedV2_Y;

/* Model entry point functions */
extern void FlightControlSystemCascadedV2_initialize(void);
extern void FlightControlSystemCascadedV2_step(void);
extern void FlightControlSystemCascadedV2_terminate(void);

/* Real-time Model object */
extern RT_MODEL_FlightControlSystemC_T *const FlightControlSystemCascadedV_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'FlightControlSystemCascadedV2'
 * '<S1>'   : 'FlightControlSystemCascadedV2/ControlLoop'
 * '<S2>'   : 'FlightControlSystemCascadedV2/Fault Detection'
 * '<S3>'   : 'FlightControlSystemCascadedV2/Ramp'
 * '<S4>'   : 'FlightControlSystemCascadedV2/Sensor Validation'
 * '<S5>'   : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID'
 * '<S6>'   : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD'
 * '<S7>'   : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Anti-windup'
 * '<S8>'   : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/D Gain'
 * '<S9>'   : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Filter'
 * '<S10>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Filter ICs'
 * '<S11>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/I Gain'
 * '<S12>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Ideal P Gain'
 * '<S13>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Ideal P Gain Fdbk'
 * '<S14>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Integrator'
 * '<S15>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Integrator ICs'
 * '<S16>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/N Copy'
 * '<S17>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/N Gain'
 * '<S18>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/P Copy'
 * '<S19>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Parallel P Gain'
 * '<S20>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Reset Signal'
 * '<S21>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Saturation'
 * '<S22>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Saturation Fdbk'
 * '<S23>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Sum'
 * '<S24>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Sum Fdbk'
 * '<S25>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tracking Mode'
 * '<S26>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tracking Mode Sum'
 * '<S27>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tsamp - Integral'
 * '<S28>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tsamp - Ngain'
 * '<S29>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/postSat Signal'
 * '<S30>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/preSat Signal'
 * '<S31>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Anti-windup/Back Calculation'
 * '<S32>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/D Gain/Internal Parameters'
 * '<S33>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Filter/Cont. Filter'
 * '<S34>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Filter ICs/Internal IC - Filter'
 * '<S35>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/I Gain/Internal Parameters'
 * '<S36>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Ideal P Gain/Passthrough'
 * '<S37>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Ideal P Gain Fdbk/Disabled'
 * '<S38>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Integrator/Continuous'
 * '<S39>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Integrator ICs/Internal IC'
 * '<S40>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/N Copy/Disabled'
 * '<S41>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/N Gain/Internal Parameters'
 * '<S42>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/P Copy/Disabled'
 * '<S43>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Parallel P Gain/Internal Parameters'
 * '<S44>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Reset Signal/Disabled'
 * '<S45>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Saturation/Enabled'
 * '<S46>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Saturation Fdbk/Disabled'
 * '<S47>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Sum/Sum_PID'
 * '<S48>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Sum Fdbk/Disabled'
 * '<S49>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tracking Mode/Disabled'
 * '<S50>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tracking Mode Sum/Passthrough'
 * '<S51>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tsamp - Integral/TsSignalSpecification'
 * '<S52>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/Tsamp - Ngain/Passthrough'
 * '<S53>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/postSat Signal/Forward_Path'
 * '<S54>'  : 'FlightControlSystemCascadedV2/ControlLoop/Altitude PID/preSat Signal/Forward_Path'
 * '<S55>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Anti-windup'
 * '<S56>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/D Gain'
 * '<S57>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Filter'
 * '<S58>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Filter ICs'
 * '<S59>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/I Gain'
 * '<S60>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Ideal P Gain'
 * '<S61>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Ideal P Gain Fdbk'
 * '<S62>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Integrator'
 * '<S63>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Integrator ICs'
 * '<S64>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/N Copy'
 * '<S65>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/N Gain'
 * '<S66>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/P Copy'
 * '<S67>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Parallel P Gain'
 * '<S68>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Reset Signal'
 * '<S69>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Saturation'
 * '<S70>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Saturation Fdbk'
 * '<S71>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Sum'
 * '<S72>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Sum Fdbk'
 * '<S73>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tracking Mode'
 * '<S74>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tracking Mode Sum'
 * '<S75>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tsamp - Integral'
 * '<S76>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tsamp - Ngain'
 * '<S77>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/postSat Signal'
 * '<S78>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/preSat Signal'
 * '<S79>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Anti-windup/Disabled'
 * '<S80>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/D Gain/Internal Parameters'
 * '<S81>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Filter/Cont. Filter'
 * '<S82>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Filter ICs/Internal IC - Filter'
 * '<S83>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/I Gain/Disabled'
 * '<S84>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Ideal P Gain/Passthrough'
 * '<S85>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Ideal P Gain Fdbk/Disabled'
 * '<S86>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Integrator/Disabled'
 * '<S87>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Integrator ICs/Disabled'
 * '<S88>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/N Copy/Disabled'
 * '<S89>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/N Gain/Internal Parameters'
 * '<S90>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/P Copy/Disabled'
 * '<S91>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Parallel P Gain/Internal Parameters'
 * '<S92>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Reset Signal/Disabled'
 * '<S93>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Saturation/Passthrough'
 * '<S94>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Saturation Fdbk/Disabled'
 * '<S95>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Sum/Sum_PD'
 * '<S96>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Sum Fdbk/Disabled'
 * '<S97>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tracking Mode/Disabled'
 * '<S98>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tracking Mode Sum/Passthrough'
 * '<S99>'  : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tsamp - Integral/TsSignalSpecification'
 * '<S100>' : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/Tsamp - Ngain/Passthrough'
 * '<S101>' : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/postSat Signal/Forward_Path'
 * '<S102>' : 'FlightControlSystemCascadedV2/ControlLoop/Pitch PD/preSat Signal/Forward_Path'
 * '<S103>' : 'FlightControlSystemCascadedV2/Fault Detection/Actual Altitude < 0'
 * '<S104>' : 'FlightControlSystemCascadedV2/Fault Detection/Actual Altitude < 1'
 * '<S105>' : 'FlightControlSystemCascadedV2/Fault Detection/Actual Altitude > 1'
 * '<S106>' : 'FlightControlSystemCascadedV2/Fault Detection/Actual Altitude > 4'
 * '<S107>' : 'FlightControlSystemCascadedV2/Sensor Validation/Less than 0m'
 * '<S108>' : 'FlightControlSystemCascadedV2/Sensor Validation/Less than 30�'
 * '<S109>' : 'FlightControlSystemCascadedV2/Sensor Validation/More than 12000m'
 * '<S110>' : 'FlightControlSystemCascadedV2/Sensor Validation/More than 30�'
 */
#endif                         /* RTW_HEADER_FlightControlSystemCascadedV2_h_ */
