/*
 * FlightControlSystemCascadedV2.c
 *
 * Code generation for model "FlightControlSystemCascadedV2".
 *
 * Model version              : 1.48
 * Simulink Coder version : 23.2 (R2023b) 01-Aug-2023
 * C source code generated on : Mon Jun 30 13:11:24 2025
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "FlightControlSystemCascadedV2.h"
#include "rtwtypes.h"
#include <math.h>
#include "FlightControlSystemCascadedV2_private.h"
#include <string.h>
#include "rt_nonfinite.h"

/* Block signals (default storage) */
B_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_B;

/* Continuous states */
X_FlightControlSystemCascaded_T FlightControlSystemCascadedV2_X;

/* Disabled State Vector */
XDis_FlightControlSystemCasca_T FlightControlSystemCascade_XDis;

/* Block states (default storage) */
DW_FlightControlSystemCascade_T FlightControlSystemCascadedV_DW;

/* External outputs (root outports fed by signals with default storage) */
ExtY_FlightControlSystemCasca_T FlightControlSystemCascadedV2_Y;

/* Real-time model */
static RT_MODEL_FlightControlSystemC_T FlightControlSystemCascadedV_M_;
RT_MODEL_FlightControlSystemC_T *const FlightControlSystemCascadedV_M =
  &FlightControlSystemCascadedV_M_;

/*
 * This function updates continuous states using the ODE4 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = (ODE4_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 7;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  FlightControlSystemCascadedV2_derivatives();

  /* f1 = f(t + (h/2), y + (h/2)*f0) */
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  FlightControlSystemCascadedV2_step();
  FlightControlSystemCascadedV2_derivatives();

  /* f2 = f(t + (h/2), y + (h/2)*f1) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  FlightControlSystemCascadedV2_step();
  FlightControlSystemCascadedV2_derivatives();

  /* f3 = f(t + h, y + h*f2) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  FlightControlSystemCascadedV2_step();
  FlightControlSystemCascadedV2_derivatives();

  /* tnew = t + h
     ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3) */
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void FlightControlSystemCascadedV2_step(void)
{
  if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    /* set solver stop time */
    if (!(FlightControlSystemCascadedV_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&FlightControlSystemCascadedV_M->solverInfo,
                            ((FlightControlSystemCascadedV_M->Timing.clockTickH0
        + 1) * FlightControlSystemCascadedV_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&FlightControlSystemCascadedV_M->solverInfo,
                            ((FlightControlSystemCascadedV_M->Timing.clockTick0
        + 1) * FlightControlSystemCascadedV_M->Timing.stepSize0 +
        FlightControlSystemCascadedV_M->Timing.clockTickH0 *
        FlightControlSystemCascadedV_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(FlightControlSystemCascadedV_M)) {
    FlightControlSystemCascadedV_M->Timing.t[0] = rtsiGetT
      (&FlightControlSystemCascadedV_M->solverInfo);
  }

  {
    real_T deltaT;
    real_T deltaT_tmp;
    real_T riseValLimit;
    real_T rtb_AltitudeError;
    real_T rtb_Pitchrate;
    real_T rtb_Saturation;
    real_T rtb_Sum_j;
    real_T rtb_Typeofdisturbance;
    boolean_T rtb_LogicalOperator1_e;

    /* Integrator: '<Root>/Altitude_Integrator' */
    FlightControlSystemCascadedV2_B.ActualAltitude =
      FlightControlSystemCascadedV2_X.Altitude_Integrator_CSTATE;

    /* Outport: '<Root>/Altitude' */
    FlightControlSystemCascadedV2_Y.Altitude =
      FlightControlSystemCascadedV2_B.ActualAltitude;

    /* Logic: '<S2>/Logical Operator' incorporates:
     *  Constant: '<S103>/Constant'
     *  Constant: '<S106>/Constant'
     *  RelationalOperator: '<S103>/Compare'
     *  RelationalOperator: '<S106>/Compare'
     */
    FlightControlSystemCascadedV2_B.LogicalOperator =
      ((FlightControlSystemCascadedV2_B.ActualAltitude <
        FlightControlSystemCascadedV2_P.ActualAltitude0_const) ||
       (FlightControlSystemCascadedV2_B.ActualAltitude >
        FlightControlSystemCascadedV2_P.ActualAltitude4_const));
    if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
      /* Logic: '<S2>/Logical Operator1' incorporates:
       *  Constant: '<S104>/Constant'
       *  Constant: '<S105>/Constant'
       *  RelationalOperator: '<S104>/Compare'
       *  RelationalOperator: '<S105>/Compare'
       */
      rtb_LogicalOperator1_e =
        ((FlightControlSystemCascadedV2_P.ActualAltitude1_const > 0.0) ||
         (FlightControlSystemCascadedV2_P.ActualAltitude1_const_f < 0.0));
    }

    /* SignalGenerator: '<Root>/Signal Generator' incorporates:
     *  Clock: '<S3>/Clock'
     *  SignalGenerator: '<Root>/Signal Generator1'
     */
    rtb_AltitudeError = FlightControlSystemCascadedV_M->Timing.t[0];
    rtb_Sum_j = FlightControlSystemCascadedV2_P.SignalGenerator_Frequency *
      rtb_AltitudeError;

    /* SignalGenerator: '<Root>/Signal Generator1' */
    rtb_Saturation = FlightControlSystemCascadedV2_P.SignalGenerator1_Frequency *
      rtb_AltitudeError;

    /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
     *  Constant: '<Root>/Constant1'
     */
    switch ((int32_T)FlightControlSystemCascadedV2_P.Constant1_Value) {
     case 1:
      /* Step: '<Root>/Step_DesiredAltitude' */
      if (FlightControlSystemCascadedV_M->Timing.t[0] <
          FlightControlSystemCascadedV2_P.Step_DesiredAltitude_Time) {
        /* MultiPortSwitch: '<Root>/Multiport Switch' */
        FlightControlSystemCascadedV2_B.MultiportSwitch =
          FlightControlSystemCascadedV2_P.Step_DesiredAltitude_Y0;
      } else {
        /* MultiPortSwitch: '<Root>/Multiport Switch' */
        FlightControlSystemCascadedV2_B.MultiportSwitch =
          FlightControlSystemCascadedV2_P.Step_DesiredAltitude_YFinal;
      }

      /* End of Step: '<Root>/Step_DesiredAltitude' */
      break;

     case 2:
      /* Step: '<S3>/Step' */
      if (FlightControlSystemCascadedV_M->Timing.t[0] <
          FlightControlSystemCascadedV2_P.Ramp_start) {
        rtb_Sum_j = FlightControlSystemCascadedV2_P.Step_Y0;
      } else {
        rtb_Sum_j = FlightControlSystemCascadedV2_P.Ramp_slope;
      }

      /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
       *  Constant: '<S3>/Constant'
       *  Constant: '<S3>/Constant1'
       *  Product: '<S3>/Product'
       *  Step: '<S3>/Step'
       *  Sum: '<S3>/Output'
       *  Sum: '<S3>/Sum'
       */
      FlightControlSystemCascadedV2_B.MultiportSwitch = (rtb_AltitudeError -
        FlightControlSystemCascadedV2_P.Ramp_start) * rtb_Sum_j +
        FlightControlSystemCascadedV2_P.Ramp_InitialOutput;
      break;

     case 3:
      /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
       *  Sin: '<Root>/Sine Wave'
       */
      FlightControlSystemCascadedV2_B.MultiportSwitch = sin
        (FlightControlSystemCascadedV2_P.SineWave_Freq *
         FlightControlSystemCascadedV_M->Timing.t[0] +
         FlightControlSystemCascadedV2_P.SineWave_Phase) *
        FlightControlSystemCascadedV2_P.SineWave_Amp +
        FlightControlSystemCascadedV2_P.SineWave_Bias;
      break;

     case 4:
      /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
       *  SignalGenerator: '<Root>/Signal Generator'
       */
      FlightControlSystemCascadedV2_B.MultiportSwitch = (1.0 - (rtb_Sum_j -
        floor(rtb_Sum_j)) * 2.0) *
        FlightControlSystemCascadedV2_P.SignalGenerator_Amplitude;
      break;

     default:
      /* SignalGenerator: '<Root>/Signal Generator1' */
      if (rtb_Saturation - floor(rtb_Saturation) >= 0.5) {
        /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
         *  SignalGenerator: '<Root>/Signal Generator1'
         */
        FlightControlSystemCascadedV2_B.MultiportSwitch =
          FlightControlSystemCascadedV2_P.SignalGenerator1_Amplitude;
      } else {
        /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
         *  SignalGenerator: '<Root>/Signal Generator1'
         */
        FlightControlSystemCascadedV2_B.MultiportSwitch =
          -FlightControlSystemCascadedV2_P.SignalGenerator1_Amplitude;
      }
      break;
    }

    /* End of MultiPortSwitch: '<Root>/Multiport Switch' */
    if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    }

    /* TransferFcn: '<Root>/Transfer Fcn (pitch)' */
    rtb_Pitchrate = FlightControlSystemCascadedV2_P.TransferFcnpitch_C[0] *
      FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[0] +
      FlightControlSystemCascadedV2_P.TransferFcnpitch_C[1] *
      FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[1];

    /* RateLimiter: '<S1>/Rate Limiter' */
    if (FlightControlSystemCascadedV_DW.LastMajorTime == (rtInf)) {
      /* RateLimiter: '<S1>/Rate Limiter' */
      FlightControlSystemCascadedV2_B.RateLimiter = rtb_Pitchrate;
    } else {
      deltaT_tmp = FlightControlSystemCascadedV_M->Timing.t[0];
      deltaT = deltaT_tmp - FlightControlSystemCascadedV_DW.LastMajorTime;
      if (FlightControlSystemCascadedV_DW.LastMajorTime == deltaT_tmp) {
        if (FlightControlSystemCascadedV_DW.PrevLimited) {
          /* RateLimiter: '<S1>/Rate Limiter' */
          FlightControlSystemCascadedV2_B.RateLimiter =
            FlightControlSystemCascadedV_DW.PrevY;
        } else {
          /* RateLimiter: '<S1>/Rate Limiter' */
          FlightControlSystemCascadedV2_B.RateLimiter = rtb_Pitchrate;
        }
      } else {
        riseValLimit = deltaT *
          FlightControlSystemCascadedV2_P.RateLimiter_RisingLim;
        deltaT_tmp = rtb_Pitchrate - FlightControlSystemCascadedV_DW.PrevY;
        if (deltaT_tmp > riseValLimit) {
          /* RateLimiter: '<S1>/Rate Limiter' */
          FlightControlSystemCascadedV2_B.RateLimiter =
            FlightControlSystemCascadedV_DW.PrevY + riseValLimit;
          rtb_LogicalOperator1_e = true;
        } else {
          deltaT *= FlightControlSystemCascadedV2_P.RateLimiter_FallingLim;
          if (deltaT_tmp < deltaT) {
            /* RateLimiter: '<S1>/Rate Limiter' */
            FlightControlSystemCascadedV2_B.RateLimiter =
              FlightControlSystemCascadedV_DW.PrevY + deltaT;
            rtb_LogicalOperator1_e = true;
          } else {
            /* RateLimiter: '<S1>/Rate Limiter' */
            FlightControlSystemCascadedV2_B.RateLimiter = rtb_Pitchrate;
            rtb_LogicalOperator1_e = false;
          }
        }

        if (rtsiIsModeUpdateTimeStep(&FlightControlSystemCascadedV_M->solverInfo))
        {
          FlightControlSystemCascadedV_DW.PrevLimited = rtb_LogicalOperator1_e;
        }
      }
    }

    /* End of RateLimiter: '<S1>/Rate Limiter' */

    /* Sum: '<S1>/Altitude Error' */
    rtb_AltitudeError = FlightControlSystemCascadedV2_B.MultiportSwitch -
      FlightControlSystemCascadedV2_B.ActualAltitude;

    /* Integrator: '<S38>/Integrator' */
    /* Limited  Integrator  */
    if (FlightControlSystemCascadedV2_X.Integrator_CSTATE >=
        FlightControlSystemCascadedV2_P.AltitudePID_UpperIntegratorSatu) {
      FlightControlSystemCascadedV2_X.Integrator_CSTATE =
        FlightControlSystemCascadedV2_P.AltitudePID_UpperIntegratorSatu;
    } else if (FlightControlSystemCascadedV2_X.Integrator_CSTATE <=
               FlightControlSystemCascadedV2_P.AltitudePID_LowerIntegratorSatu)
    {
      FlightControlSystemCascadedV2_X.Integrator_CSTATE =
        FlightControlSystemCascadedV2_P.AltitudePID_LowerIntegratorSatu;
    }

    /* Gain: '<S41>/Filter Coefficient' incorporates:
     *  Gain: '<S32>/Derivative Gain'
     *  Integrator: '<S33>/Filter'
     *  Sum: '<S33>/SumD'
     */
    FlightControlSystemCascadedV2_B.FilterCoefficient =
      (FlightControlSystemCascadedV2_P.AltitudePID_D * rtb_AltitudeError -
       FlightControlSystemCascadedV2_X.Filter_CSTATE) *
      FlightControlSystemCascadedV2_P.AltitudePID_N;

    /* Sum: '<S47>/Sum' incorporates:
     *  Gain: '<S43>/Proportional Gain'
     *  Integrator: '<S38>/Integrator'
     */
    rtb_Sum_j = (FlightControlSystemCascadedV2_P.AltitudePID_P *
                 rtb_AltitudeError +
                 FlightControlSystemCascadedV2_X.Integrator_CSTATE) +
      FlightControlSystemCascadedV2_B.FilterCoefficient;

    /* Saturate: '<S45>/Saturation' */
    if (rtb_Sum_j >
        FlightControlSystemCascadedV2_P.AltitudePID_UpperSaturationLimi) {
      rtb_Saturation =
        FlightControlSystemCascadedV2_P.AltitudePID_UpperSaturationLimi;
    } else if (rtb_Sum_j <
               FlightControlSystemCascadedV2_P.AltitudePID_LowerSaturationLimi)
    {
      rtb_Saturation =
        FlightControlSystemCascadedV2_P.AltitudePID_LowerSaturationLimi;
    } else {
      rtb_Saturation = rtb_Sum_j;
    }

    /* End of Saturate: '<S45>/Saturation' */

    /* Sum: '<S1>/Pitch Error' */
    rtb_Typeofdisturbance = rtb_Saturation -
      FlightControlSystemCascadedV2_B.RateLimiter;

    /* Gain: '<S89>/Filter Coefficient' incorporates:
     *  Gain: '<S80>/Derivative Gain'
     *  Integrator: '<S81>/Filter'
     *  Sum: '<S81>/SumD'
     */
    FlightControlSystemCascadedV2_B.FilterCoefficient_h =
      (FlightControlSystemCascadedV2_P.PitchPD_D * rtb_Typeofdisturbance -
       FlightControlSystemCascadedV2_X.Filter_CSTATE_d) *
      FlightControlSystemCascadedV2_P.PitchPD_N;

    /* ManualSwitch: '<Root>/Automatic//Manual mode' incorporates:
     *  Constant: '<S107>/Constant'
     *  Constant: '<S108>/Constant'
     *  Constant: '<S109>/Constant'
     *  Constant: '<S110>/Constant'
     *  Logic: '<Root>/Sensor fault detected'
     *  Logic: '<S4>/Logical Operator'
     *  Logic: '<S4>/Logical Operator1'
     *  RelationalOperator: '<S107>/Compare'
     *  RelationalOperator: '<S108>/Compare'
     *  RelationalOperator: '<S109>/Compare'
     *  RelationalOperator: '<S110>/Compare'
     *  Switch: '<Root>/Switch'
     */
    if (FlightControlSystemCascadedV2_P.AutomaticManualmode_CurrentSett == 1) {
      /* Step: '<Root>/Manual Elevator Cmd' */
      if (FlightControlSystemCascadedV_M->Timing.t[0] <
          FlightControlSystemCascadedV2_P.ManualElevatorCmd_Time) {
        rtb_Typeofdisturbance =
          FlightControlSystemCascadedV2_P.ManualElevatorCmd_Y0;
      } else {
        rtb_Typeofdisturbance =
          FlightControlSystemCascadedV2_P.ManualElevatorCmd_YFinal;
      }

      /* End of Step: '<Root>/Manual Elevator Cmd' */
    } else if ((rtb_Pitchrate < FlightControlSystemCascadedV2_P.Lessthan30_const)
               || (rtb_Pitchrate >
                   FlightControlSystemCascadedV2_P.Morethan30_const) ||
               ((FlightControlSystemCascadedV2_B.ActualAltitude <
                 FlightControlSystemCascadedV2_P.Lessthan0m_const) ||
                (FlightControlSystemCascadedV2_B.ActualAltitude >
                 FlightControlSystemCascadedV2_P.Morethan12000m_const))) {
      /* Switch: '<Root>/Switch' incorporates:
       *  Constant: '<Root>/Safe elevator cmd'
       */
      rtb_Typeofdisturbance =
        FlightControlSystemCascadedV2_P.Safeelevatorcmd_Value;
    } else {
      /* Switch: '<Root>/Switch' incorporates:
       *  Gain: '<S91>/Proportional Gain'
       *  Sum: '<S95>/Sum'
       */
      rtb_Typeofdisturbance = FlightControlSystemCascadedV2_P.PitchPD_P *
        rtb_Typeofdisturbance +
        FlightControlSystemCascadedV2_B.FilterCoefficient_h;
    }

    /* End of ManualSwitch: '<Root>/Automatic//Manual mode' */

    /* RateLimiter: '<Root>/Actuator limiter' */
    if (FlightControlSystemCascadedV_DW.LastMajorTime_a == (rtInf)) {
      /* RateLimiter: '<Root>/Actuator limiter' */
      FlightControlSystemCascadedV2_B.Actuatorlimiter = rtb_Typeofdisturbance;
    } else {
      deltaT_tmp = FlightControlSystemCascadedV_M->Timing.t[0];
      deltaT = deltaT_tmp - FlightControlSystemCascadedV_DW.LastMajorTime_a;
      if (FlightControlSystemCascadedV_DW.LastMajorTime_a == deltaT_tmp) {
        if (FlightControlSystemCascadedV_DW.PrevLimited_g) {
          /* RateLimiter: '<Root>/Actuator limiter' */
          FlightControlSystemCascadedV2_B.Actuatorlimiter =
            FlightControlSystemCascadedV_DW.PrevY_g;
        } else {
          /* RateLimiter: '<Root>/Actuator limiter' */
          FlightControlSystemCascadedV2_B.Actuatorlimiter =
            rtb_Typeofdisturbance;
        }
      } else {
        riseValLimit = deltaT *
          FlightControlSystemCascadedV2_P.Actuatorlimiter_RisingLim;
        deltaT_tmp = rtb_Typeofdisturbance -
          FlightControlSystemCascadedV_DW.PrevY_g;
        if (deltaT_tmp > riseValLimit) {
          /* RateLimiter: '<Root>/Actuator limiter' */
          FlightControlSystemCascadedV2_B.Actuatorlimiter =
            FlightControlSystemCascadedV_DW.PrevY_g + riseValLimit;
          rtb_LogicalOperator1_e = true;
        } else {
          deltaT *= FlightControlSystemCascadedV2_P.Actuatorlimiter_FallingLim;
          if (deltaT_tmp < deltaT) {
            /* RateLimiter: '<Root>/Actuator limiter' */
            FlightControlSystemCascadedV2_B.Actuatorlimiter =
              FlightControlSystemCascadedV_DW.PrevY_g + deltaT;
            rtb_LogicalOperator1_e = true;
          } else {
            /* RateLimiter: '<Root>/Actuator limiter' */
            FlightControlSystemCascadedV2_B.Actuatorlimiter =
              rtb_Typeofdisturbance;
            rtb_LogicalOperator1_e = false;
          }
        }

        if (rtsiIsModeUpdateTimeStep(&FlightControlSystemCascadedV_M->solverInfo))
        {
          FlightControlSystemCascadedV_DW.PrevLimited_g = rtb_LogicalOperator1_e;
        }
      }
    }

    /* End of RateLimiter: '<Root>/Actuator limiter' */
    if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
      /* DiscretePulseGenerator: '<Root>/Pitch disturbance pulse' */
      if ((FlightControlSystemCascadedV_DW.clockTickCounter <
           FlightControlSystemCascadedV2_P.Pitchdisturbancepulse_Duty) &&
          (FlightControlSystemCascadedV_DW.clockTickCounter >= 0)) {
        /* DiscretePulseGenerator: '<Root>/Pitch disturbance pulse' */
        FlightControlSystemCascadedV2_B.Pitchdisturbancepulse =
          FlightControlSystemCascadedV2_P.Pitchdisturbancepulse_Amp;
      } else {
        /* DiscretePulseGenerator: '<Root>/Pitch disturbance pulse' */
        FlightControlSystemCascadedV2_B.Pitchdisturbancepulse = 0.0;
      }

      if (FlightControlSystemCascadedV_DW.clockTickCounter >=
          FlightControlSystemCascadedV2_P.Pitchdisturbancepulse_Period - 1.0) {
        FlightControlSystemCascadedV_DW.clockTickCounter = 0;
      } else {
        FlightControlSystemCascadedV_DW.clockTickCounter++;
      }

      /* End of DiscretePulseGenerator: '<Root>/Pitch disturbance pulse' */
    }

    /* MultiPortSwitch: '<Root>/Type of disturbance' incorporates:
     *  Constant: '<Root>/Constant2'
     */
    if ((int32_T)FlightControlSystemCascadedV2_P.Constant2_Value == 1) {
      /* Step: '<Root>/Pitch disturbance step' */
      if (FlightControlSystemCascadedV_M->Timing.t[0] <
          FlightControlSystemCascadedV2_P.Pitchdisturbancestep_Time) {
        rtb_Typeofdisturbance =
          FlightControlSystemCascadedV2_P.Pitchdisturbancestep_Y0;
      } else {
        rtb_Typeofdisturbance =
          FlightControlSystemCascadedV2_P.Pitchdisturbancestep_YFinal;
      }

      /* End of Step: '<Root>/Pitch disturbance step' */
    } else {
      rtb_Typeofdisturbance =
        FlightControlSystemCascadedV2_B.Pitchdisturbancepulse;
    }

    /* End of MultiPortSwitch: '<Root>/Type of disturbance' */

    /* Sum: '<Root>/Sum disturbance' */
    FlightControlSystemCascadedV2_B.Sumdisturbance =
      FlightControlSystemCascadedV2_B.Actuatorlimiter - rtb_Typeofdisturbance;
    if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    }

    /* Sum: '<S31>/SumI4' incorporates:
     *  Gain: '<S31>/Kb'
     *  Gain: '<S35>/Integral Gain'
     *  Sum: '<S31>/SumI2'
     */
    FlightControlSystemCascadedV2_B.SumI4 = (rtb_Saturation - rtb_Sum_j) *
      FlightControlSystemCascadedV2_P.AltitudePID_Kb +
      FlightControlSystemCascadedV2_P.AltitudePID_I * rtb_AltitudeError;

    /* Gain: '<Root>/Gain (PitchRateToSpeed)' */
    FlightControlSystemCascadedV2_B.VerticalAcceleration =
      FlightControlSystemCascadedV2_P.GainPitchRateToSpeed_Gain * rtb_Pitchrate;

    /* Integrator: '<Root>/Vertical speed' */
    FlightControlSystemCascadedV2_B.Verticalspeed =
      FlightControlSystemCascadedV2_X.Verticalspeed_CSTATE;
  }

  if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(FlightControlSystemCascadedV_M->rtwLogInfo,
                        (FlightControlSystemCascadedV_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    real_T LastMajorTime_tmp;

    /* Update for RateLimiter: '<S1>/Rate Limiter' incorporates:
     *  RateLimiter: '<Root>/Actuator limiter'
     */
    FlightControlSystemCascadedV_DW.PrevY =
      FlightControlSystemCascadedV2_B.RateLimiter;
    LastMajorTime_tmp = FlightControlSystemCascadedV_M->Timing.t[0];
    FlightControlSystemCascadedV_DW.LastMajorTime = LastMajorTime_tmp;

    /* Update for RateLimiter: '<Root>/Actuator limiter' */
    FlightControlSystemCascadedV_DW.PrevY_g =
      FlightControlSystemCascadedV2_B.Actuatorlimiter;
    FlightControlSystemCascadedV_DW.LastMajorTime_a = LastMajorTime_tmp;
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(FlightControlSystemCascadedV_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(FlightControlSystemCascadedV_M)!=-1) &&
          !((rtmGetTFinal(FlightControlSystemCascadedV_M)-
             (((FlightControlSystemCascadedV_M->Timing.clockTick1+
                FlightControlSystemCascadedV_M->Timing.clockTickH1* 4294967296.0))
              * 0.001)) > (((FlightControlSystemCascadedV_M->Timing.clockTick1+
                             FlightControlSystemCascadedV_M->Timing.clockTickH1*
              4294967296.0)) * 0.001) * (DBL_EPSILON))) {
        rtmSetErrorStatus(FlightControlSystemCascadedV_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&FlightControlSystemCascadedV_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++FlightControlSystemCascadedV_M->Timing.clockTick0)) {
      ++FlightControlSystemCascadedV_M->Timing.clockTickH0;
    }

    FlightControlSystemCascadedV_M->Timing.t[0] = rtsiGetSolverStopTime
      (&FlightControlSystemCascadedV_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.001, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      FlightControlSystemCascadedV_M->Timing.clockTick1++;
      if (!FlightControlSystemCascadedV_M->Timing.clockTick1) {
        FlightControlSystemCascadedV_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void FlightControlSystemCascadedV2_derivatives(void)
{
  XDot_FlightControlSystemCasca_T *_rtXdot;
  boolean_T lsat;
  boolean_T usat;
  _rtXdot = ((XDot_FlightControlSystemCasca_T *)
             FlightControlSystemCascadedV_M->derivs);

  /* Derivatives for Integrator: '<Root>/Altitude_Integrator' */
  _rtXdot->Altitude_Integrator_CSTATE =
    FlightControlSystemCascadedV2_B.Verticalspeed;

  /* Derivatives for TransferFcn: '<Root>/Transfer Fcn (pitch)' */
  _rtXdot->TransferFcnpitch_CSTATE[0] =
    FlightControlSystemCascadedV2_P.TransferFcnpitch_A[0] *
    FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[0];
  _rtXdot->TransferFcnpitch_CSTATE[0] +=
    FlightControlSystemCascadedV2_P.TransferFcnpitch_A[1] *
    FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[1];
  _rtXdot->TransferFcnpitch_CSTATE[1] =
    FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[0];
  _rtXdot->TransferFcnpitch_CSTATE[0] +=
    FlightControlSystemCascadedV2_B.Sumdisturbance;

  /* Derivatives for Integrator: '<S38>/Integrator' */
  lsat = (FlightControlSystemCascadedV2_X.Integrator_CSTATE <=
          FlightControlSystemCascadedV2_P.AltitudePID_LowerIntegratorSatu);
  usat = (FlightControlSystemCascadedV2_X.Integrator_CSTATE >=
          FlightControlSystemCascadedV2_P.AltitudePID_UpperIntegratorSatu);
  if (((!lsat) && (!usat)) || (lsat && (FlightControlSystemCascadedV2_B.SumI4 >
        0.0)) || (usat && (FlightControlSystemCascadedV2_B.SumI4 < 0.0))) {
    _rtXdot->Integrator_CSTATE = FlightControlSystemCascadedV2_B.SumI4;
  } else {
    /* in saturation */
    _rtXdot->Integrator_CSTATE = 0.0;
  }

  /* End of Derivatives for Integrator: '<S38>/Integrator' */

  /* Derivatives for Integrator: '<S33>/Filter' */
  _rtXdot->Filter_CSTATE = FlightControlSystemCascadedV2_B.FilterCoefficient;

  /* Derivatives for Integrator: '<S81>/Filter' */
  _rtXdot->Filter_CSTATE_d = FlightControlSystemCascadedV2_B.FilterCoefficient_h;

  /* Derivatives for Integrator: '<Root>/Vertical speed' */
  _rtXdot->Verticalspeed_CSTATE =
    FlightControlSystemCascadedV2_B.VerticalAcceleration;
}

/* Model initialize function */
void FlightControlSystemCascadedV2_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)FlightControlSystemCascadedV_M, 0,
                sizeof(RT_MODEL_FlightControlSystemC_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&FlightControlSystemCascadedV_M->solverInfo,
                          &FlightControlSystemCascadedV_M->Timing.simTimeStep);
    rtsiSetTPtr(&FlightControlSystemCascadedV_M->solverInfo, &rtmGetTPtr
                (FlightControlSystemCascadedV_M));
    rtsiSetStepSizePtr(&FlightControlSystemCascadedV_M->solverInfo,
                       &FlightControlSystemCascadedV_M->Timing.stepSize0);
    rtsiSetdXPtr(&FlightControlSystemCascadedV_M->solverInfo,
                 &FlightControlSystemCascadedV_M->derivs);
    rtsiSetContStatesPtr(&FlightControlSystemCascadedV_M->solverInfo, (real_T **)
                         &FlightControlSystemCascadedV_M->contStates);
    rtsiSetNumContStatesPtr(&FlightControlSystemCascadedV_M->solverInfo,
      &FlightControlSystemCascadedV_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&FlightControlSystemCascadedV_M->solverInfo,
      &FlightControlSystemCascadedV_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&FlightControlSystemCascadedV_M->solverInfo,
       &FlightControlSystemCascadedV_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&FlightControlSystemCascadedV_M->solverInfo,
       &FlightControlSystemCascadedV_M->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&FlightControlSystemCascadedV_M->solverInfo,
      (boolean_T**) &FlightControlSystemCascadedV_M->contStateDisabled);
    rtsiSetErrorStatusPtr(&FlightControlSystemCascadedV_M->solverInfo,
                          (&rtmGetErrorStatus(FlightControlSystemCascadedV_M)));
    rtsiSetRTModelPtr(&FlightControlSystemCascadedV_M->solverInfo,
                      FlightControlSystemCascadedV_M);
  }

  rtsiSetSimTimeStep(&FlightControlSystemCascadedV_M->solverInfo,
                     MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange
    (&FlightControlSystemCascadedV_M->solverInfo, false);
  FlightControlSystemCascadedV_M->intgData.y =
    FlightControlSystemCascadedV_M->odeY;
  FlightControlSystemCascadedV_M->intgData.f[0] =
    FlightControlSystemCascadedV_M->odeF[0];
  FlightControlSystemCascadedV_M->intgData.f[1] =
    FlightControlSystemCascadedV_M->odeF[1];
  FlightControlSystemCascadedV_M->intgData.f[2] =
    FlightControlSystemCascadedV_M->odeF[2];
  FlightControlSystemCascadedV_M->intgData.f[3] =
    FlightControlSystemCascadedV_M->odeF[3];
  FlightControlSystemCascadedV_M->contStates = ((X_FlightControlSystemCascaded_T
    *) &FlightControlSystemCascadedV2_X);
  FlightControlSystemCascadedV_M->contStateDisabled =
    ((XDis_FlightControlSystemCasca_T *) &FlightControlSystemCascade_XDis);
  FlightControlSystemCascadedV_M->Timing.tStart = (0.0);
  rtsiSetSolverData(&FlightControlSystemCascadedV_M->solverInfo, (void *)
                    &FlightControlSystemCascadedV_M->intgData);
  rtsiSetSolverName(&FlightControlSystemCascadedV_M->solverInfo,"ode4");
  rtmSetTPtr(FlightControlSystemCascadedV_M,
             &FlightControlSystemCascadedV_M->Timing.tArray[0]);
  rtmSetTFinal(FlightControlSystemCascadedV_M, 120.0);
  FlightControlSystemCascadedV_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    FlightControlSystemCascadedV_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(FlightControlSystemCascadedV_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(FlightControlSystemCascadedV_M->rtwLogInfo, (NULL));
    rtliSetLogT(FlightControlSystemCascadedV_M->rtwLogInfo, "tout");
    rtliSetLogX(FlightControlSystemCascadedV_M->rtwLogInfo, "");
    rtliSetLogXFinal(FlightControlSystemCascadedV_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(FlightControlSystemCascadedV_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(FlightControlSystemCascadedV_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(FlightControlSystemCascadedV_M->rtwLogInfo, 0);
    rtliSetLogDecimation(FlightControlSystemCascadedV_M->rtwLogInfo, 1);
    rtliSetLogY(FlightControlSystemCascadedV_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(FlightControlSystemCascadedV_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(FlightControlSystemCascadedV_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &FlightControlSystemCascadedV2_B), 0,
                sizeof(B_FlightControlSystemCascaded_T));

  /* states (continuous) */
  {
    (void) memset((void *)&FlightControlSystemCascadedV2_X, 0,
                  sizeof(X_FlightControlSystemCascaded_T));
  }

  /* disabled states */
  {
    (void) memset((void *)&FlightControlSystemCascade_XDis, 0,
                  sizeof(XDis_FlightControlSystemCasca_T));
  }

  /* states (dwork) */
  (void) memset((void *)&FlightControlSystemCascadedV_DW, 0,
                sizeof(DW_FlightControlSystemCascade_T));

  /* external outputs */
  FlightControlSystemCascadedV2_Y.Altitude = 0.0;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(FlightControlSystemCascadedV_M->rtwLogInfo,
    0.0, rtmGetTFinal(FlightControlSystemCascadedV_M),
    FlightControlSystemCascadedV_M->Timing.stepSize0, (&rtmGetErrorStatus
    (FlightControlSystemCascadedV_M)));

  /* Start for DiscretePulseGenerator: '<Root>/Pitch disturbance pulse' */
  FlightControlSystemCascadedV_DW.clockTickCounter = 0;

  /* InitializeConditions for Integrator: '<Root>/Altitude_Integrator' */
  FlightControlSystemCascadedV2_X.Altitude_Integrator_CSTATE =
    FlightControlSystemCascadedV2_P.Altitude_Integrator_IC;

  /* InitializeConditions for TransferFcn: '<Root>/Transfer Fcn (pitch)' */
  FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[0] = 0.0;
  FlightControlSystemCascadedV2_X.TransferFcnpitch_CSTATE[1] = 0.0;

  /* InitializeConditions for RateLimiter: '<S1>/Rate Limiter' */
  FlightControlSystemCascadedV_DW.LastMajorTime = (rtInf);

  /* InitializeConditions for Integrator: '<S38>/Integrator' */
  FlightControlSystemCascadedV2_X.Integrator_CSTATE =
    FlightControlSystemCascadedV2_P.AltitudePID_InitialConditionF_o;

  /* InitializeConditions for Integrator: '<S33>/Filter' */
  FlightControlSystemCascadedV2_X.Filter_CSTATE =
    FlightControlSystemCascadedV2_P.AltitudePID_InitialConditionFor;

  /* InitializeConditions for Integrator: '<S81>/Filter' */
  FlightControlSystemCascadedV2_X.Filter_CSTATE_d =
    FlightControlSystemCascadedV2_P.PitchPD_InitialConditionForFilt;

  /* InitializeConditions for RateLimiter: '<Root>/Actuator limiter' */
  FlightControlSystemCascadedV_DW.LastMajorTime_a = (rtInf);

  /* InitializeConditions for Integrator: '<Root>/Vertical speed' */
  FlightControlSystemCascadedV2_X.Verticalspeed_CSTATE =
    FlightControlSystemCascadedV2_P.Verticalspeed_IC;
}

/* Model terminate function */
void FlightControlSystemCascadedV2_terminate(void)
{
  /* (no terminate code required) */
}
